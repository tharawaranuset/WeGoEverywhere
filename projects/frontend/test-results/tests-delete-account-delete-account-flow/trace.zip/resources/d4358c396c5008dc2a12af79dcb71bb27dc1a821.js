(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a8db915d._.js",
  "static/chunks/src_ddc0dd87._.js"
],
    source: "dynamic"
});
