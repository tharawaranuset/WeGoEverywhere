(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__cfee4145._.css",
  "static/chunks/node_modules_04138f4c._.js",
  "static/chunks/src_components_popup_ConfirmProvider_tsx_8da75cc7._.js"
],
    source: "dynamic"
});
