(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/popup/ConfirmProvider.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ConfirmProvider": ()=>ConfirmProvider,
    "useConfirm": ()=>useConfirm
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const ConfirmCtx = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useConfirm() {
    _s();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ConfirmCtx);
    if (!ctx) throw new Error("useConfirm must be used within <ConfirmProvider>");
    return ctx;
}
_s(useConfirm, "/dMy7t63NXD4eYACoT93CePwGrg=");
function ConfirmProvider(param) {
    let { children } = param;
    _s1();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [opts, setOpts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [resolver, setResolver] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "ConfirmProvider.useState": ()=>({
                "ConfirmProvider.useState": ()=>{}
            })["ConfirmProvider.useState"]
    }["ConfirmProvider.useState"]);
    const confirm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ConfirmProvider.useCallback[confirm]": (o)=>{
            //ค่าdefault
            setOpts({
                confirmText: "Confirm",
                cancelText: "Cancel",
                variant: "default",
                ...o
            });
            setOpen(true);
            return new Promise({
                "ConfirmProvider.useCallback[confirm]": (resolve)=>setResolver({
                        "ConfirmProvider.useCallback[confirm]": ()=>resolve
                    }["ConfirmProvider.useCallback[confirm]"])
            }["ConfirmProvider.useCallback[confirm]"]);
        }
    }["ConfirmProvider.useCallback[confirm]"], []);
    const close = (v)=>{
        setOpen(false);
        resolver(v);
    };
    const baseBtn = "h-11 w-full rounded-full font-semibold cursor-pointer select-none " + "transition-all duration-200 ease-out " + "focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 " + "active:translate-y-[1px] motion-safe:hover:-translate-y-0.5";
    const isDanger = (opts === null || opts === void 0 ? void 0 : opts.variant) === "danger";
    const confirmBtnClass = baseBtn + (isDanger ? " border-red-700 bg-[#B71402] text-white " + "hover:bg-red-700 focus-visible:ring-red-400 ring-offset-[#FFF5E9] " + "shadow-[0_2px_0_rgba(0,0,0,0.15)] motion-safe:hover:shadow-[0_8px_16px_rgba(220,38,38,0.25)]" : " border-black bg-[#FFDCD5] text-black " + "hover:opacity-95 focus-visible:ring-black/40 ring-offset-[#FFF5E9] " + "shadow-[0_2px_0_rgba(0,0,0,0.08)] motion-safe:hover:shadow-[0_8px_16px_rgba(0,0,0,0.08)]");
    const cancelBtnClass = baseBtn + " border-black bg-white text-black hover:bg-gray-50 " + "focus-visible:ring-black/40 ring-offset-[#FFF5E9] " + "shadow-[0_2px_0_rgba(0,0,0,0.06)] motion-safe:hover:shadow-[0_8px_16px_rgba(0,0,0,0.06)]";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfirmCtx.Provider, {
        value: confirm,
        children: [
            children,
            open && opts && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[9999] grid place-items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-black/40",
                        onClick: ()=>close(false)
                    }, void 0, false, {
                        fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative w-[280px] max-w-sm rounded-[20px] bg-[#FFF5E9] p-6 shadow-xl font-alt ",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center text-lg leading-tight font-bold",
                                children: opts.title
                            }, void 0, false, {
                                fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                                lineNumber: 79,
                                columnNumber: 13
                            }, this),
                            opts.subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-sm text-black/70 text-center",
                                children: opts.subtitle
                            }, void 0, false, {
                                fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                                lineNumber: 83,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-6 flex flex-col gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>close(true),
                                        className: confirmBtnClass,
                                        children: opts.confirmText
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                                        lineNumber: 89,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>close(false),
                                        className: cancelBtnClass,
                                        children: opts.cancelText
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                                        lineNumber: 92,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                                lineNumber: 88,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                        lineNumber: 78,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
                lineNumber: 73,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/popup/ConfirmProvider.tsx",
        lineNumber: 70,
        columnNumber: 5
    }, this);
}
_s1(ConfirmProvider, "xKcUw8nmJOjJueLsk3PIOD+etP0=");
_c = ConfirmProvider;
var _c;
__turbopack_context__.k.register(_c, "ConfirmProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_components_popup_ConfirmProvider_tsx_8da75cc7._.js.map