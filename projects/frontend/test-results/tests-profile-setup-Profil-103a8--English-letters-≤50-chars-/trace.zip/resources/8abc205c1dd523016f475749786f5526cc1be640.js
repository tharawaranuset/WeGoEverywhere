(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7e5553a8._.js",
  "static/chunks/node_modules_ebd4830c._.js"
],
    source: "dynamic"
});
